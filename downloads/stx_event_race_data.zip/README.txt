Saint Xavier Track & Cross-Country Event and Race Data
======================================================

Result rows: 90,310
Race/event rows: 2,331
Race dates: 1950-05-20 through 2026-08-08

Files
-----
stx_results.csv: One row per stored result, including splits and source links.
stx_race_events.csv: One row per race/event/division combination.
data_dictionary.csv: Column descriptions for the results file.

Notes
-----
This is a normalized historical dataset assembled from multiple public sources.
Blank values indicate that a field was not available or did not apply.
Times in numeric fields are expressed in seconds.
